addpath /usr/local/lib
